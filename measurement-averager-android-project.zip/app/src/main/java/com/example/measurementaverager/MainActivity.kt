package com.example.measurementaverager

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val blue = Color.rgb(25, 103, 210)
    private val navy = Color.rgb(25, 42, 85)
    private val green = Color.rgb(0, 92, 62)
    private var measurements = listOf<Int>()
    private lateinit var valuesView: TextView
    private lateinit var averageView: TextView
    private lateinit var statusView: TextView
    private lateinit var recordButton: Button

    companion object { private const val REQUEST_SPEECH = 42; private const val REQUEST_AUDIO = 43 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        updateResult()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247, 250, 255))
            setPadding(dp(24), dp(18), dp(24), dp(20))
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            setBackgroundColor(blue)
        }
        header.addView(text("Measurement Averager", 30, Color.WHITE, true))
        header.addView(text("Speak 3 measurements  •  Get the average", 17, Color.WHITE, false))
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        val instructions = text("Tap Record and say your 3 measurements\n(e.g. eighty, eighty-nine, seventy-seven)", 21, navy, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(28), dp(8), dp(18))
        }
        root.addView(instructions, LinearLayout.LayoutParams(-1, -2))

        recordButton = Button(this).apply {
            text = "🎙  TAP TO RECORD"
            textSize = 22f
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue))
            isAllCaps = false
            setOnClickListener { beginRecording() }
        }
        root.addView(recordButton, LinearLayout.LayoutParams(-1, dp(72)))

        statusView = text("Ready when you are.", 16, navy, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(10))
        }
        root.addView(statusView, LinearLayout.LayoutParams(-1, -2))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(228, 247, 239)); cornerRadius = dp(16).toFloat()
            }
        }
        card.addView(text("Measurements", 18, green, false))
        valuesView = text("—", 31, green, true).apply { gravity = Gravity.CENTER }
        card.addView(valuesView)
        card.addView(text("Average", 18, green, false).apply { setPadding(0, dp(8), 0, 0) })
        averageView = text("—", 38, green, true).apply { gravity = Gravity.CENTER }
        card.addView(averageView)
        root.addView(card, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            topMargin = dp(12); bottomMargin = dp(12)
        })

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val clear = Button(this).apply {
            text = "Clear"
            textSize = 18f
            isAllCaps = false
            setOnClickListener { clearResults() }
        }
        val again = Button(this).apply {
            text = "Record Again"
            textSize = 18f
            isAllCaps = false
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue))
            setTextColor(Color.WHITE)
            setOnClickListener { beginRecording() }
        }
        buttons.addView(clear, LinearLayout.LayoutParams(0, dp(58), 1f).apply { marginEnd = dp(8) })
        buttons.addView(again, LinearLayout.LayoutParams(0, dp(58), 1f).apply { marginStart = dp(8) })
        root.addView(buttons, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun beginRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_AUDIO)
            return
        }
        val recognizer = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Say three measurements, for example: eighty, eighty-nine, seventy-seven")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        }
        try {
            startActivityForResult(recognizer, REQUEST_SPEECH)
        } catch (_: Exception) {
            statusView.text = "Speech recognition isn't available on this tablet. Check that a speech service is installed."
            Toast.makeText(this, "Speech recognition unavailable", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_AUDIO && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) beginRecording()
        else if (requestCode == REQUEST_AUDIO) statusView.text = "Microphone permission is needed to record measurements."
    }

    @Deprecated("Uses Android's system speech recognition activity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_SPEECH || resultCode != RESULT_OK) {
            if (requestCode == REQUEST_SPEECH) statusView.text = "Recording cancelled. Tap Record to try again."
            return
        }
        val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
        val parsed = parseThreeNumbers(spoken)
        if (parsed == null) {
            statusView.text = "I heard: “$spoken”. Please try again and say exactly three numbers."
            Toast.makeText(this, "Couldn't find exactly three measurements", Toast.LENGTH_LONG).show()
            return
        }
        measurements = parsed
        statusView.text = "Heard: “$spoken”"
        updateResult()
    }

    private fun parseThreeNumbers(spoken: String): List<Int>? {
        val normal = spoken.lowercase(Locale.getDefault())
            .replace(Regex("[-,;.]"), " ")
            .replace(Regex("\\b(and)\\b"), " ")
            .trim()
        val tokens = normal.split(Regex("\\s+")).filter { it.isNotBlank() }
        val found = mutableListOf<Int>()
        val numberWords = mapOf(
            "zero" to 0, "oh" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4,
            "five" to 5, "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9,
            "ten" to 10, "eleven" to 11, "twelve" to 12, "thirteen" to 13, "fourteen" to 14,
            "fifteen" to 15, "sixteen" to 16, "seventeen" to 17, "eighteen" to 18,
            "nineteen" to 19, "twenty" to 20, "thirty" to 30, "forty" to 40,
            "fifty" to 50, "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90
        )
        var i = 0
        while (i < tokens.size) {
            val token = tokens[i].trim { !it.isLetterOrDigit() }
            val numeric = token.toIntOrNull()
            if (numeric != null) {
                found.add(numeric); i++; continue
            }
            val wordVal = numberWords[token]
            if (wordVal != null) {
                if (wordVal >= 20 && wordVal % 10 == 0 && i + 1 < tokens.size) {
                    val next = numberWords[tokens[i + 1].trim { !it.isLetterOrDigit() }]
                    if (next != null && next in 1..9) {
                        found.add(wordVal + next); i += 2; continue
                    }
                }
                found.add(wordVal)
            }
            i++
        }
        if (found.size < 3) return null
        val three = found.takeLast(3)
        if (three.any { it !in 0..99 }) return null
        return three
    }

    private fun updateResult() {
        if (measurements.size == 3) {
            valuesView.text = measurements.joinToString(", ") { it.toString().padStart(2, '0') }
            val averageHundredths = measurements.average().roundToInt()
            averageView.text = "50.${averageHundredths.toString().padStart(2, '0')}"
        } else {
            valuesView.text = "—"
            averageView.text = "—"
        }
    }

    private fun clearResults() {
        measurements = emptyList()
        statusView.text = "Ready when you are."
        updateResult()
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value; textSize = size.toFloat(); setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
}
