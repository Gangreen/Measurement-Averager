# Measurement Averager (Android)

A simple native Android tablet app that uses Android's system speech-recognition screen to hear three spoken measurement endings (for example, “eighty, eighty-nine, seventy-seven”), then displays those endings and the average as `50.xx`.

For 80, 89, 77, the average ending is 82, so the displayed result is `50.82`.

## Build an APK in GitHub Actions

1. Create a GitHub account and a new **public or private repository** named `measurement-averager`.
2. Upload the contents of this project (the files and folders inside this ZIP) to the repository's `main` branch.
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Choose **Build Android APK** and click **Run workflow**, or push a commit to `main`.
5. When the run finishes successfully, open the run, scroll to **Artifacts**, and download `measurement-averager-apk`.
6. Extract the downloaded artifact ZIP to find `app-debug.apk`.
7. Transfer the APK to the Android tablet and open it to install. Android may ask you to allow installation from that source.

## Notes

- The app requests microphone permission when you first record.
- Speech recognition depends on an Android speech-recognition service being available on the tablet; the service may use an internet connection.
- The app expects three whole-number endings from 00 to 99 and uses the last three recognized numbers if extra numbers are returned.
- The average is rounded to the nearest hundredth of the base measurement: `50.` plus the rounded average ending. If you want a different fixed leading number, change `50.` in `MainActivity.kt`.
- This is a starter project. The GitHub build has not been run from this chat, so the APK still needs to be built and tested on your tablet.
